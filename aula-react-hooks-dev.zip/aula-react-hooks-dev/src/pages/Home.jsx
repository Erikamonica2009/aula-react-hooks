export default function Home() {
  return (
    <div>
      <h1>Bem-vindo ao Dog Gallery 🐕</h1>
      <p>Veja fotos aleatórias de cachorros fofos!</p>
    </div>
  );
}
