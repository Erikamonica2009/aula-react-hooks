export default function About() {
  return (
    <div>
      <h1>Sobre o Projeto</h1>
      <p>Este projeto usa:</p>
      <ul>
        <li>React Hooks (useState, useEffect)</li>
        <li>React Router (rotas)</li>
        <li>API pública de cachorros (dog.ceo)</li>
      </ul>
    </div>
  );
}
